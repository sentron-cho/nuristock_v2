INSERT INTO nuristock_v2.app (sgroup,skey,svalue,utime,ctime) VALUES
	 ('dashboard','more','false','2025-08-07 21:19:59','2025-08-07 21:19:59'),
	 ('dashboard','sort','keepCost','2025-08-15 13:52:24','2025-08-07 21:20:19');
