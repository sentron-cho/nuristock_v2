INSERT INTO nuristock_v2.deposit (stype,sdate,price,utime,ctime) VALUES
	 ('menual','20250815081518',990435,'2025-08-15 07:36:49','2025-08-15 07:36:49');
