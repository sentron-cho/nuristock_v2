INSERT INTO nuristock.uset (userid,stag,skey,sval,utime) VALUES
	 (171620000001,'bucket','config','{"save":"1000000","base":"6000000","rate":"10","start":"20200101","year":"12"}','2024-03-15 19:49:58');
