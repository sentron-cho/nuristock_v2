INSERT INTO nuristock.settings (accountid,category,skey,svalue) VALUES
	 (171620000001,2,'is_screen_lock','true'),
	 (171620000001,2,'stock_bank_price','4845542'),
	 (171620000001,2,'stock_tax_percent','0.3'),
	 (171620000001,2,'stock_cms_percent','0.015'),
	 (171620000001,2,'stock_sort_main','profit desc'),
	 (171620000001,2,'stock_cms_checked','true'),
	 (171620000001,2,'stock_company','이베스트투자증권'),
	 (171620000001,2,'screen_lock_password','0000'),
	 (171620000001,1,'money_prologue_ok','true'),
	 (171620000001,1,'is_screen_lock','true');
INSERT INTO nuristock.settings (accountid,category,skey,svalue) VALUES
	 (171620000001,0,'is_screen_lock','false'),
	 (171620000001,0,'screen_lock_password','0000');
