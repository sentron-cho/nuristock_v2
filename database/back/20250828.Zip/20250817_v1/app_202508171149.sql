INSERT INTO nuristock.app (ctag,grp,skey,sval,ops,cont,ctime) VALUES
	 ('app','config','saying_version','1',NULL,NULL,'2020-02-14 16:39:29');
