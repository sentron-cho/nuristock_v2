INSERT INTO nuristock.users (userid,accountid,auth,pwd,email,name,phone,kakaoid,token,reset_pwd,utime,ctime) VALUES
	 (171620000001,'sentron@hanmail.net','user','1XtRvui7i9XEdcI1B/9J0Rhe2vg==','sentron@hanmail.net','조병호','01032992464','415796316',NULL,'N','2018-03-29 07:51:55','2017-06-11 12:27:14'),
	 (171620000002,'sentron','admin','1XtRvui7i9XEdcI1B/9J0Rhe2vg==','sentron9601@gmail.com','조병호','01032992464',NULL,NULL,'Y','2018-03-14 14:34:11','2017-06-11 12:30:54'),
	 (1557797880497,'sentron@gmail.com','user','1XtRvui7i9XEdcI1B/9J0Rhe2vg==','sentron@gmail.com','조병호','01032992464',NULL,NULL,'N','2019-05-14 10:36:41','2019-05-14 10:36:41'),
	 (1600232691000,'sentron1@hanmail.net','user','xEDUolkVC8gi4lzMUN71NT3++fQ==','sentron1@hanmail.net',NULL,'01033333223',NULL,NULL,'N','2020-09-16 14:03:23','2020-09-16 14:03:23');
