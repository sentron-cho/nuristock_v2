INSERT INTO nuristock_v2.app (sgroup,skey,svalue,ctime,utime) VALUES
	 ('dashboard','more','true','2025-08-07 21:19:59','2025-08-23 18:33:29'),
	 ('dashboard','sort','keepCost','2025-08-07 21:20:19','2025-08-25 12:35:33');
