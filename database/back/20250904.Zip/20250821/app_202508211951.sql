INSERT INTO nuristock_v2.app (sgroup,skey,svalue,ctime,utime) VALUES
	 ('dashboard','more','false','2025-08-07 21:19:59','2025-08-07 21:19:59'),
	 ('dashboard','sort','keepCost','2025-08-07 21:20:19','2025-08-20 09:08:38');
